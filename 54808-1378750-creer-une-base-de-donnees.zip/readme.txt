Cr�er une base de donn�es-------------------------
Url     : http://codes-sources.commentcamarche.net/source/54808-creer-une-base-de-donneesAuteur  : cs_ChevalDate    : 05/08/2013
Licence :
=========

Ce document intitul� � Cr�er une base de donn�es � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Cr&eacute;ation d'une base de donn&eacute;es Lorsque la base est construite le l
ogiciel cr&eacute;&eacute; une apli pour lire et &eacute;crire dans la base
<br
 />pour les novices cela leur montre comment construire une base mais surtout co
mment faire une appli pour lire et &eacute;crire dans une base.
<br />Certaines
 routines ont &eacute;t&eacute; prises sur le site mais je ne me rappele plus de
 qui... J'esp&egrave;re qu'ils se reconnaitront
<br />J'avais relev&eacute; les
 noms il y a plusieur mois mais je ne retrouve pas la feuille ou tout etait not&
eacute;.... pardon
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br
 />Il y a un fichier help qui s'appele &quot;lisez-moi.chm&quot;
